﻿
using Verse;

namespace NewHatcher
{
    public class CompProperties_AberrantMucus : CompProperties
    {


        

        public CompProperties_AberrantMucus()
        {
            //Messages.Message("Patataaa", MessageSound.Standard);
            this.compClass = typeof(CompAberrantMucus);
        }
    }
}
